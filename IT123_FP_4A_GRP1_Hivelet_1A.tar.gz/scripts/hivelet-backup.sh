#!/bin/bash
# ==============================================================================
# Script Name: hivelet-backup.sh
# Purpose:     Creates a dated, compressed backup archive containing the
#              application configuration, data, database dump, and code.
#              Verifies archive integrity using tar verification and sha256.
# Authors:     BSIT 4A/4B - IT 123 Capstone Group
# Usage:       sudo ./hivelet-backup.sh [OPTIONS] [DESTINATION]
# Options:     --help     Display this help message and exit
# Destination: Optional custom directory (default: /var/backups/hivelet)
# ==============================================================================

set -euo pipefail

APP_DIR="/opt/hivelet"
DEFAULT_BACKUP_DIR="/var/backups/hivelet"
TIMESTAMP="$(date +'%Y-%m-%d_%H%M%S')"

# Function: Display usage instructions
show_help() {
  cat << EOF
Usage: sudo ./hivelet-backup.sh [OPTIONS] [DESTINATION_DIR]

Archives and compresses Hivelet application files and database dump,
then verifies that the resulting archive is complete and readable.

ARGUMENTS:
  DESTINATION_DIR   Optional custom backup directory (default: ${DEFAULT_BACKUP_DIR})

OPTIONS:
  --help, -h        Show this help message and exit

EXAMPLES:
  sudo ./hivelet-backup.sh
  sudo ./hivelet-backup.sh /tmp/backups

EXIT STATUS:
  0 on success, non-zero on failure.
EOF
  exit 0
}

# Handle command-line options
if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  show_help
fi

# Privilege Check: Backup operations require appropriate read/write privileges
if [ "${EUID}" -ne 0 ] && [ ! -w "${DEFAULT_BACKUP_DIR}" ]; then
  echo "[-] ERROR: Root privileges required to write to system backup directory." >&2
  echo "[-] Please run: sudo $0" >&2
  exit 1
fi

DEST_DIR="${1:-${DEFAULT_BACKUP_DIR}}"
mkdir -p "${DEST_DIR}"

BACKUP_NAME="hivelet_backup_${TIMESTAMP}.tar.gz"
BACKUP_PATH="${DEST_DIR}/${BACKUP_NAME}"
CHECKSUM_PATH="${BACKUP_PATH}.sha256"
TEMP_DUMP_DIR="/tmp/hivelet_db_dump_${TIMESTAMP}"

echo "===================================================================="
echo " Hivelet Backup and Verification: Starting"
echo " Timestamp: ${TIMESTAMP}"
echo " Destination: ${BACKUP_PATH}"
echo "===================================================================="

# Step 1: Perform database export
echo "[+] Step 1/4: Exporting database tables and records..."
mkdir -p "${TEMP_DUMP_DIR}"

if [ -f "${APP_DIR}/scripts/backup-database.mjs" ] && command -v node >/dev/null 2>&1; then
  echo "    Executing database dump via Node.js data exporter..."
  (cd "${APP_DIR}" && node scripts/backup-database.mjs >/dev/null 2>&1) || true
  if [ -d "${APP_DIR}/backups" ]; then
    LATEST_DUMP="$(ls -td "${APP_DIR}/backups"/* 2>/dev/null | head -1 || true)"
    if [ -n "${LATEST_DUMP}" ] && [ -d "${LATEST_DUMP}" ]; then
      cp -r "${LATEST_DUMP}"/* "${TEMP_DUMP_DIR}/"
    fi
  fi
fi

# Step 2: Create compressed tar archive
echo "[+] Step 2/4: Archiving and compressing application files..."
tar --exclude="node_modules" \
    --exclude=".git" \
    --exclude="dist" \
    -czf "${BACKUP_PATH}" \
    -C "${APP_DIR}" . \
    -C "${TEMP_DUMP_DIR}" .

# Step 3: Verify archive integrity (tar test)
echo "[+] Step 3/4: Verifying archive completeness and readability..."
if tar -tzf "${BACKUP_PATH}" >/dev/null 2>&1; then
  echo "    [✔] Archive structure test: PASSED (Readable and valid gzip stream)"
else
  echo "    [✘] Archive verification failed! Archive may be corrupted." >&2
  rm -f "${BACKUP_PATH}"
  exit 2
fi

# Step 4: Generate cryptographic checksum
echo "[+] Step 4/4: Calculating SHA-256 integrity checksum..."
sha256sum "${BACKUP_PATH}" | awk '{print $1}' > "${CHECKSUM_PATH}"

# Clean temporary dump files
rm -rf "${TEMP_DUMP_DIR}"

# Summary and statistics
ARCHIVE_SIZE="$(du -h "${BACKUP_PATH}" | cut -f1)"
FILE_COUNT="$(tar -ztf "${BACKUP_PATH}" | wc -l)"

echo "===================================================================="
echo " Backup successfully created and verified!"
echo " File:      ${BACKUP_PATH}"
echo " Checksum:  $(cat "${CHECKSUM_PATH}")"
echo " Size:      ${ARCHIVE_SIZE}"
echo " Contents:  ${FILE_COUNT} files archived"
echo " Status:    COMPLETE (Exit code: 0)"
echo "===================================================================="

exit 0
