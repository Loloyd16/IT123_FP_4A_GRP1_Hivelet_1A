#!/bin/bash
# ==============================================================================
# Script Name: hivelet-health.sh
# Purpose:     Generates a unified system and application health report.
#              Audits CPU load, memory utilization, disk space, network ports,
#              and systemd service operational status in one readable dashboard.
# Authors:     BSIT 4A/4B - IT 123 Capstone Group
# Usage:       ./hivelet-health.sh [OPTIONS]
# Options:     --help     Display this help message and exit
# ==============================================================================

set -euo pipefail

SERVICE_NAME="hivelet.service"

# Function: Display usage instructions
show_help() {
  cat << EOF
Usage: ./hivelet-health.sh [OPTIONS]

Generates a real-time system and service health report for Hivelet.

OPTIONS:
  --help, -h        Show this help message and exit

EXAMPLES:
  ./hivelet-health.sh
  sudo ./hivelet-health.sh

EXIT STATUS:
  0 on success, non-zero on failure.
EOF
  exit 0
}

# Handle command-line options
if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  show_help
fi

echo "===================================================================="
echo "          HIVELET SYSTEM HEALTH & PERFORMANCE REPORT               "
echo "          Generated: $(date '+%Y-%m-%d %H:%M:%S')                  "
echo "===================================================================="

# 1. CPU Load Average
echo ""
echo "--- 1. PROCESSOR & SYSTEM LOAD ---"
UPTIME_RAW="$(uptime)"
LOAD_AVG="$(echo "${UPTIME_RAW}" | awk -F'load average:' '{print $2}' | xargs)"
echo "  System Uptime : $(uptime -p 2>/dev/null || uptime)"
echo "  Load Averages : ${LOAD_AVG} (1m, 5m, 15m)"
echo "  CPU Cores     : $(nproc 2>/dev/null || echo 1)"

# 2. Memory Utilization
echo ""
echo "--- 2. MEMORY UTILIZATION ---"
if command -v free >/dev/null 2>&1; then
  free -h | awk 'NR==1{printf "  %-12s %-10s %-10s %-10s %-10s\n", $1, $2, $3, $4, $7} NR==2{printf "  %-12s %-10s %-10s %-10s %-10s\n", "RAM:", $2, $3, $4, $7} NR==3{printf "  %-12s %-10s %-10s %-10s %-10s\n", "Swap:", $2, $3, $4, "-"}'
else
  echo "  [!] 'free' command not available."
fi

# 3. Disk Space Utilization
echo ""
echo "--- 3. STORAGE & DISK UTILIZATION ---"
df -h / | awk 'NR==1{printf "  %-15s %-10s %-10s %-10s %-10s %s\n", $1, $2, $3, $4, $5, $6} NR==2{printf "  %-15s %-10s %-10s %-10s %-10s %s\n", $1, $2, $3, $4, $5, $6}'

# 4. Service Operational Status
echo ""
echo "--- 4. APPLICATION & SYSTEM SERVICES ---"

# Check Hivelet backend service
if command -v systemctl >/dev/null 2>&1; then
  HIVELET_STATUS="$(systemctl is-active "${SERVICE_NAME}" 2>/dev/null || echo "inactive")"
  if [ "${HIVELET_STATUS}" = "active" ]; then
    echo "  [✔] ${SERVICE_NAME}        : ACTIVE (Running)"
  else
    echo "  [✘] ${SERVICE_NAME}        : INACTIVE / STOPPED"
  fi

  # Check SSH service
  SSH_STATUS="$(systemctl is-active ssh 2>/dev/null || systemctl is-active sshd 2>/dev/null || echo "unknown")"
  echo "  [✔] ssh.service            : ${SSH_STATUS}"
else
  echo "  [!] systemctl not found on this environment."
fi

# 5. Network Connectivity & API Liveness
echo ""
echo "--- 5. NETWORK & PORT LIVENESS ---"
PORT_OPEN=0
if command -v ss >/dev/null 2>&1; then
  if ss -tlpn 2>/dev/null | grep -q ":5000 "; then
    PORT_OPEN=1
  fi
fi

if [ "${PORT_OPEN}" -eq 1 ] || curl -sf http://127.0.0.1:5000/api/health >/dev/null 2>&1; then
  echo "  [✔] API Port 5000          : LISTENING & RESPONDING"
else
  echo "  [?] API Port 5000          : NOT LISTENING or STARTING"
fi

echo ""
echo "--- 6. APPLICATION ACCESS LINKS ---"
SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")"
[ -z "${SERVER_IP}" ] && SERVER_IP="127.0.0.1"
echo "  🌐 Web App URL   : http://${SERVER_IP}:5173"
echo "  🔌 API Endpoint  : http://${SERVER_IP}:5000/api/health"

echo ""
echo "===================================================================="
echo " System Status Check Finished with Exit Code 0"
echo "===================================================================="
exit 0
