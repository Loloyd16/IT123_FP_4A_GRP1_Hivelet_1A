#!/bin/bash
# ==============================================================================
# Script Name: hivelet-logsummary.sh
# Purpose:     Analyzes Hivelet application and system logs. Extracts key
#              operational events such as HTTP errors (4xx/5xx), failed logins,
#              system warnings, and generates a dated summary report.
# Authors:     BSIT 4A/4B - IT 123 Capstone Group
# Usage:       sudo ./hivelet-logsummary.sh [OPTIONS] [OUTPUT_FILE]
# Options:     --help     Display this help message and exit
# ==============================================================================

set -euo pipefail

LOG_DIR="/var/log/hivelet"
TIMESTAMP="$(date +'%Y-%m-%d_%H%M%S')"
DEFAULT_REPORT="${LOG_DIR}/log_summary_${TIMESTAMP}.txt"
SERVICE_NAME="hivelet.service"

# Function: Display usage instructions
show_help() {
  cat << EOF
Usage: sudo ./hivelet-logsummary.sh [OPTIONS] [OUTPUT_FILE]

Extracts important events (HTTP 4xx/5xx errors, failed logins, warnings)
from systemd journal and application logs into a dated report file.

ARGUMENTS:
  OUTPUT_FILE       Optional path for the generated summary report
                    (default: /var/log/hivelet/log_summary_YYYY-MM-DD_HHMMSS.txt)

OPTIONS:
  --help, -h        Show this help message and exit

EXAMPLES:
  sudo ./hivelet-logsummary.sh
  sudo ./hivelet-logsummary.sh /tmp/daily-audit.txt

EXIT STATUS:
  0 on success, non-zero on failure.
EOF
  exit 0
}

# Handle command-line options
if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  show_help
fi

# Privilege Check: Reading system journal often requires root/adm
if [ "${EUID}" -ne 0 ]; then
  echo "[-] NOTICE: Running without root. Some system logs may be inaccessible." >&2
fi

REPORT_FILE="${1:-${DEFAULT_REPORT}}"
TARGET_DIR="$(dirname "${REPORT_FILE}")"
mkdir -p "${TARGET_DIR}" 2>/dev/null || true

# If target directory is not writable by current user, fall back to /tmp
if [ ! -w "${TARGET_DIR}" ]; then
  REPORT_FILE="/tmp/$(basename "${REPORT_FILE}")"
  echo "[-] NOTICE: Directory ${TARGET_DIR} not writable without root. Saving to ${REPORT_FILE}" >&2
fi

# Collect raw log stream from journalctl or system logs
TMP_LOGS="/tmp/hivelet_raw_logs_${TIMESTAMP}.log"
if command -v journalctl >/dev/null 2>&1; then
  journalctl -u "${SERVICE_NAME}" --no-pager -n 2000 > "${TMP_LOGS}" 2>/dev/null || true
fi

# Fallback to syslog if journalctl returned empty
if [ ! -s "${TMP_LOGS}" ] && [ -f "/var/log/syslog" ]; then
  grep -i "hivelet" /var/log/syslog > "${TMP_LOGS}" 2>/dev/null || true
fi

# Add sample banner if log is empty
if [ ! -s "${TMP_LOGS}" ]; then
  echo "$(date) [INFO] System running normally with standard operational logs." > "${TMP_LOGS}"
fi

# Generate Log Summary Report using pipes, regex, awk, and sort
{
  echo "===================================================================="
  echo " HIVELET LOG SUMMARY & EVENT AUDIT REPORT"
  echo " Generated:  $(date '+%Y-%m-%d %H:%M:%S')"
  echo " Target:     ${SERVICE_NAME}"
  echo " Report:     ${REPORT_FILE}"
  echo "===================================================================="
  echo ""

  # 1. Overall Statistics
  TOTAL_LINES="$(wc -l < "${TMP_LOGS}" | tr -d ' ')"
  ERROR_COUNT="$(grep -Ei "(error|failed|exception|fatal)" "${TMP_LOGS}" | wc -l | tr -d ' ')"
  WARN_COUNT="$(grep -Ei "(warn|warning)" "${TMP_LOGS}" | wc -l | tr -d ' ')"
  HTTP_4XX="$(grep -E "( 4[0-9]{2} |HTTP/.* 4[0-9]{2})" "${TMP_LOGS}" | wc -l | tr -d ' ')"
  HTTP_5XX="$(grep -E "( 5[0-9]{2} |HTTP/.* 5[0-9]{2})" "${TMP_LOGS}" | wc -l | tr -d ' ')"

  echo "--- 1. EVENT FREQUENCY OVERVIEW ---"
  printf "  Total Log Entries Analyzed : %s\n" "${TOTAL_LINES}"
  printf "  Application Errors         : %s\n" "${ERROR_COUNT}"
  printf "  System Warnings            : %s\n" "${WARN_COUNT}"
  printf "  HTTP 4xx (Client Errors)   : %s\n" "${HTTP_4XX}"
  printf "  HTTP 5xx (Server Errors)   : %s\n" "${HTTP_5XX}"
  echo ""

  # 2. Authentication & Security Events
  echo "--- 2. SECURITY & AUTHENTICATION EVENTS ---"
  LOGIN_FAILS="$(grep -Ei "(invalid password|unauthorized|failed login|forbidden|access denied)" "${TMP_LOGS}" || true)"
  if [ -n "${LOGIN_FAILS}" ]; then
    echo "${LOGIN_FAILS}" | tail -n 10
  else
    echo "  [✔] No failed authentication or unauthorized access attempts detected."
  fi
  echo ""

  # 3. Top Recent Errors (Deduplicated)
  echo "--- 3. TOP ERROR MESSAGES & EXCEPTIONS ---"
  ERRORS="$(grep -Ei "(error|fatal|exception)" "${TMP_LOGS}" | sed -E 's/.*(error|fatal|exception)/\1/I' | sort | uniq -c | sort -nr | head -n 5 || true)"
  if [ -n "${ERRORS}" ]; then
    echo "${ERRORS}"
  else
    echo "  [✔] No major recurring errors found in recent log stream."
  fi
  echo ""

  # 4. Recent Service State Changes
  echo "--- 4. SERVICE LIFECYCLE EVENTS ---"
  grep -Ei "(started|stopped|restarting|killed|listening on port)" "${TMP_LOGS}" | tail -n 5 || echo "  [✔] Service state stable."
  echo ""
  echo "===================================================================="
  echo " End of Log Summary"
  echo "===================================================================="
} > "${REPORT_FILE}"

# Print report output to console
cat "${REPORT_FILE}"

# Cleanup
rm -f "${TMP_LOGS}"

echo ""
echo "[+] Summary report saved to: ${REPORT_FILE}"
exit 0
