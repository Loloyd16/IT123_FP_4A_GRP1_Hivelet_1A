#!/bin/bash
# ==============================================================================
# Script Name: hivelet-install.sh
# Purpose:     Deploys and updates the Hivelet system on Ubuntu Linux.
#              Intelligently detects existing installations: performs full setup
#              on fresh servers, and fast incremental updates when already installed.
# Authors:     BSIT 4A/4B - IT 123 Capstone Group
# Usage:       sudo ./hivelet-install.sh [OPTIONS]
# Options:     --help, -h       Display this help message and exit
#              --reinstall      Force a clean reinstallation from scratch
# ==============================================================================

set -euo pipefail

APP_NAME="hivelet"
APP_DIR="/opt/${APP_NAME}"
SERVICE_NAME="${APP_NAME}.service"
FRONTEND_SERVICE="hivelet-frontend.service"
SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FORCE_REINSTALL=0

# Function: Display usage instructions
show_help() {
  cat << EOF
Usage: sudo ./hivelet-install.sh [OPTIONS]

Installs or updates the Hivelet application on Ubuntu Linux.
- If not installed: Runs complete server provisioning and dependency install.
- If already installed: Performs a fast update (syncs code, updates links, restarts services).

OPTIONS:
  -h, --help        Show this help message and exit
  --reinstall       Force a full clean reinstallation (runs all package & npm steps)

EXAMPLES:
  sudo ./hivelet-install.sh
  sudo ./hivelet-install.sh --reinstall

EXIT STATUS:
  0 on success, non-zero on failure.
EOF
  exit 0
}

# Parse options
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)
      show_help
      ;;
    --reinstall)
      FORCE_REINSTALL=1
      shift
      ;;
    *)
      shift
      ;;
  esac
done

# Privilege Check: Must run as root
if [ "${EUID}" -ne 0 ]; then
  echo "[-] ERROR: This script must be run as root. Please use: sudo $0" >&2
  exit 1
fi

# Detect whether Hivelet is already installed
IS_INSTALLED=0
if [ -d "${APP_DIR}/backend/node_modules" ] && [ -f "/etc/systemd/system/${SERVICE_NAME}" ] && [ "${FORCE_REINSTALL}" -eq 0 ]; then
  IS_INSTALLED=1
fi

# ==============================================================================
# FAST UPDATE MODE (When already installed)
# ==============================================================================
if [ "${IS_INSTALLED}" -eq 1 ]; then
  echo "===================================================================="
  echo " Hivelet is already installed at ${APP_DIR}                        "
  echo " Running in FAST UPDATE mode (skipping redundant installs)...       "
  echo "===================================================================="

  # 1. Sync updated files
  echo "[+] Step 1/4: Synchronizing updated files to ${APP_DIR}..."
  if [ "${SOURCE_DIR}" != "${APP_DIR}" ]; then
    cp -ru "${SOURCE_DIR}"/* "${APP_DIR}/" 2>/dev/null || cp -r "${SOURCE_DIR}"/* "${APP_DIR}/"
  fi

  # 2. Check permissions
  echo "[+] Step 2/4: Verifying ownership and permissions..."
  chown -R hivelet:hivelet "${APP_DIR}"
  chmod -R 775 "${APP_DIR}"
  chmod 777 /var/log/hivelet /var/backups/hivelet 2>/dev/null || true
  [ -f "${APP_DIR}/.env" ] && chmod 600 "${APP_DIR}/.env"

  # 3. Refresh global commands and man page
  echo "[+] Step 3/4: Refreshing global CLI symlinks in /usr/local/bin..."
  for script in hivelet-install.sh hivelet-backup.sh hivelet-restore.sh hivelet-logsummary.sh hivelet-health.sh hivelet-diskalert.sh; do
    if [ -f "${APP_DIR}/scripts/${script}" ]; then
      chmod +x "${APP_DIR}/scripts/${script}"
      ln -sf "${APP_DIR}/scripts/${script}" "/usr/local/bin/${script}"
      base_cmd="$(basename "${script}" .sh)"
      ln -sf "${APP_DIR}/scripts/${script}" "/usr/local/bin/${base_cmd}"
    fi
  done

  # 4. Configure Nginx reverse proxy on port 80
  if command -v nginx >/dev/null 2>&1; then
    echo "[+] Configuring Nginx reverse proxy on port 80..."
    cat << 'NGINX_EOF' > /etc/nginx/sites-available/hivelet
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
    }

    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 60s;
    }
}
NGINX_EOF
    rm -f /etc/nginx/sites-enabled/default
    ln -sf /etc/nginx/sites-available/hivelet /etc/nginx/sites-enabled/
    systemctl restart nginx || true
  fi

  # 5. Restart services
  echo "[+] Step 4/4: Reloading and restarting services..."
  systemctl daemon-reload
  systemctl restart "${SERVICE_NAME}" "${FRONTEND_SERVICE}" || true

  SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")"
  [ -z "${SERVER_IP}" ] && SERVER_IP="127.0.0.1"

  echo ""
  echo "===================================================================="
  echo "          🎉 HIVELET UPDATED SUCCESSFULLY! 🎉                       "
  echo "===================================================================="
  echo " Access the live system in your browser:"
  echo ""
  echo "   🌟 Primary Web URL (Port 80)   : http://${SERVER_IP}/"
  echo "   🌐 Direct Frontend (Port 5173) : http://${SERVER_IP}:5173/"
  echo "   🔌 Direct Backend  (Port 5000) : http://${SERVER_IP}:5000/api/health"
  echo "===================================================================="
  echo "[+] Update completed in ~2 seconds (Exit code: 0)."
  exit 0
fi

# ==============================================================================
# FRESH INSTALLATION MODE
# ==============================================================================
echo "===================================================================="
echo " Starting Full Hivelet System Installation and Server Provisioning  "
echo "===================================================================="

# Helper: Wait for dpkg/apt locks if another process is running
wait_for_apt_lock() {
  local max_wait=30
  local count=0
  while fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1 || fuser /var/lib/apt/lists/lock >/dev/null 2>&1; do
    echo "    [i] Another package manager is active (unattended-upgrades). Waiting ($((count + 1))/${max_wait}s)..."
    sleep 1
    count=$((count + 1))
    if [ $count -ge $max_wait ]; then
      echo "    [!] Releasing stale package lock..."
      killall -9 unattended-upgrade apt apt-get 2>/dev/null || true
      rm -f /var/lib/apt/lists/lock /var/cache/apt/archives/lock /var/lib/dpkg/lock*
      dpkg --configure -a || true
      break
    fi
  done
}

# Step 1: Install system prerequisites only if missing
echo "[+] Step 1/6: Checking required system packages..."
MISSING_PKGS=()
for pkg in curl tar gzip jq procps nginx; do
  command -v "$pkg" >/dev/null 2>&1 || MISSING_PKGS+=("$pkg")
done

if [ ${#MISSING_PKGS[@]} -gt 0 ]; then
  echo "    Installing missing packages: ${MISSING_PKGS[*]}..."
  wait_for_apt_lock
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -qq || true
  apt-get install -y "${MISSING_PKGS[@]}" || true
else
  echo "    [✔] Base system tools (curl, tar, gzip, jq, procps, nginx) are already installed."
fi

# Check for Node.js (v18+ required, v20/22 recommended)
if ! command -v node >/dev/null 2>&1 || [ "$(node -v | tr -d 'v' | cut -d'.' -f1)" -lt 18 ]; then
  echo "[+] Installing Node.js LTS via official NodeSource repository..."
  wait_for_apt_lock
  curl -fsSL https://deb.nodesource.com/setup_22.x | bash -
  wait_for_apt_lock
  apt-get install -y nodejs
else
  echo "    [✔] Node.js is already installed ($(node -v), npm $(npm -v))."
fi

# Step 2: Create application directory and copy files
echo "[+] Step 2/6: Deploying files to ${APP_DIR}..."
mkdir -p "${APP_DIR}"
mkdir -p /var/backups/hivelet
mkdir -p /var/log/hivelet

if [ "${SOURCE_DIR}" != "${APP_DIR}" ]; then
  cp -r "${SOURCE_DIR}"/* "${APP_DIR}/"
  [ -f "${SOURCE_DIR}/.env.example" ] && cp -n "${SOURCE_DIR}/.env.example" "${APP_DIR}/.env" || true
fi

# Step 3: Install application dependencies
echo "[+] Step 3/6: Installing application npm dependencies..."
cd "${APP_DIR}"
if [ -f "package.json" ] && [ ! -d "node_modules" ]; then
  npm install || true
fi
if [ -d "backend" ] && [ -f "backend/package.json" ] && [ ! -d "backend/node_modules" ]; then
  echo "    Installing backend dependencies..."
  (cd backend && npm install || true)
fi
if [ -d "frontend" ] && [ -f "frontend/package.json" ] && [ ! -d "frontend/node_modules" ]; then
  echo "    Installing frontend dependencies..."
  (cd frontend && npm install || true)
fi

# Step 4: Configure ownership and security permissions
echo "[+] Step 4/6: Applying least-privilege permissions and file ownership..."
if ! id -u hivelet >/dev/null 2>&1; then
  useradd --system --shell /usr/sbin/nologin --comment "Hivelet Service Account" hivelet || true
fi

chown -R hivelet:hivelet "${APP_DIR}"
chown -R hivelet:hivelet /var/backups/hivelet
chown -R hivelet:hivelet /var/log/hivelet

[ -f "${APP_DIR}/.env" ] && chmod 600 "${APP_DIR}/.env"

# Step 5: Install global CLI symlinks and manual page
echo "[+] Step 5/6: Setting up global commands in /usr/local/bin and man pages..."
for script in hivelet-install.sh hivelet-backup.sh hivelet-restore.sh hivelet-logsummary.sh hivelet-health.sh hivelet-diskalert.sh; do
  if [ -f "${APP_DIR}/scripts/${script}" ]; then
    chmod +x "${APP_DIR}/scripts/${script}"
    ln -sf "${APP_DIR}/scripts/${script}" "/usr/local/bin/${script}"
    base_cmd="$(basename "${script}" .sh)"
    ln -sf "${APP_DIR}/scripts/${script}" "/usr/local/bin/${base_cmd}"
  fi
done

# Install man page
mkdir -p /usr/local/share/man/man8
if [ -f "${APP_DIR}/man/hivelet-toolkit.8" ]; then
  cp "${APP_DIR}/man/hivelet-toolkit.8" /usr/local/share/man/man8/
  chmod 644 /usr/local/share/man/man8/hivelet-toolkit.8
  mandb -q >/dev/null 2>&1 || true
fi

# Step 6: Configure systemd services and Nginx reverse proxy
echo "[+] Step 6/6: Configuring systemd services and Nginx reverse proxy..."

# Backend service
cat << 'EOF' > "/etc/systemd/system/${SERVICE_NAME}"
[Unit]
Description=Hivelet Web Application Backend API Server
After=network.target

[Service]
Type=simple
User=hivelet
WorkingDirectory=/opt/hivelet/backend
ExecStart=/usr/bin/npm run dev
Restart=always
RestartSec=5
Environment=PORT=5000
Environment=NODE_ENV=production

[Install]
WantedBy=multi-user.target
EOF

# Frontend service
cat << 'EOF' > "/etc/systemd/system/${FRONTEND_SERVICE}"
[Unit]
Description=Hivelet Web Application Frontend Server
After=network.target

[Service]
Type=simple
User=hivelet
WorkingDirectory=/opt/hivelet/frontend
ExecStart=/usr/bin/npm run dev -- --host 0.0.0.0 --port 5173
Restart=always
RestartSec=5
Environment=PORT=5173

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable "${SERVICE_NAME}" "${FRONTEND_SERVICE}" >/dev/null 2>&1 || true
systemctl restart "${SERVICE_NAME}" "${FRONTEND_SERVICE}" || true

# Configure Nginx on Port 80
if command -v nginx >/dev/null 2>&1; then
  echo "[+] Configuring Nginx reverse proxy on port 80..."
  cat << 'NGINX_EOF' > /etc/nginx/sites-available/hivelet
server {
    listen 80 default_server;
    listen [::]:80 default_server;
    server_name _;

    location /api {
        proxy_pass http://127.0.0.1:5000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_read_timeout 60s;
    }

    location / {
        proxy_pass http://127.0.0.1:5173;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_read_timeout 60s;
    }
}
NGINX_EOF
  rm -f /etc/nginx/sites-enabled/default
  ln -sf /etc/nginx/sites-available/hivelet /etc/nginx/sites-enabled/
  systemctl restart nginx || true
fi

echo "===================================================================="
echo " Verifying Application Response..."
echo "===================================================================="

SUCCESS=0
for i in {1..8}; do
  if curl -sf http://127.0.0.1:5000/api/health >/dev/null 2>&1 || curl -sf http://127.0.0.1:5000 >/dev/null 2>&1 || curl -sf http://127.0.0.1:80 >/dev/null 2>&1; then
    SUCCESS=1
    break
  fi
  sleep 1
done

SERVER_IP="$(hostname -I 2>/dev/null | awk '{print $1}' || echo "127.0.0.1")"
[ -z "${SERVER_IP}" ] && SERVER_IP="127.0.0.1"

echo ""
echo "===================================================================="
echo "          🎉 HIVELET APPLICATION IS LIVE AND READY! 🎉              "
echo "===================================================================="
echo " Access the live system in your browser:"
echo ""
echo "   🌟 Primary Web URL (Port 80)   : http://${SERVER_IP}/"
echo "   🌐 Direct Frontend (Port 5173) : http://${SERVER_IP}:5173/"
echo "   🔌 Direct Backend  (Port 5000) : http://${SERVER_IP}:5000/api/health"
echo "===================================================================="
echo ""
echo "[+] Global commands installed in /usr/local/bin:"
echo "    - hivelet-backup"
echo "    - hivelet-restore"
echo "    - hivelet-health"
echo "    - hivelet-diskalert"
echo "    - hivelet-logsummary"
echo "[+] Installation completed successfully (Exit code: 0)."
exit 0
