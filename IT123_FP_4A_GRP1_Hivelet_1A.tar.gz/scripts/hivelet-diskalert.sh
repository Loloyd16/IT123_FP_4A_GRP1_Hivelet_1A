#!/bin/bash
# ==============================================================================
# Script Name: hivelet-diskalert.sh
# Purpose:     Monitors root filesystem disk usage against a user-defined
#              threshold percentage. Warns loudly and exits with a non-zero
#              status code when disk usage exceeds the threshold.
# Authors:     BSIT 4A/4B - IT 123 Capstone Group
# Usage:       ./hivelet-diskalert.sh [OPTIONS] [THRESHOLD]
# Options:     --help, -h               Display this help message and exit
#              --threshold, -t <VALUE>  Set threshold percentage (1-100)
# ==============================================================================

set -euo pipefail

DEFAULT_THRESHOLD=80
THRESHOLD="${DEFAULT_THRESHOLD}"

# Function: Display usage instructions
show_help() {
  cat << EOF
Usage: ./hivelet-diskalert.sh [OPTIONS] [THRESHOLD_PERCENTAGE]

Audits disk usage on the root partition and alerts if usage exceeds threshold.
Exits with status 0 if healthy; exits with status 1 (non-zero) if threshold breached.

ARGUMENTS:
  THRESHOLD_PERCENTAGE    Integer between 1 and 100 (default: ${DEFAULT_THRESHOLD})

OPTIONS:
  -t, --threshold <NUM>   Set threshold percentage (e.g. -t 85)
  -h, --help              Show this help message and exit

EXAMPLES:
  ./hivelet-diskalert.sh
  ./hivelet-diskalert.sh 85
  ./hivelet-diskalert.sh --threshold 70

EXIT STATUS:
  0   Disk usage is below threshold (HEALTHY).
  1   Disk usage has exceeded threshold (ALERT / ACTION REQUIRED).
  2   Invalid arguments or system error.
EOF
  exit 0
}

# Parse command line arguments
while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help)
      show_help
      ;;
    -t|--threshold)
      if [ -n "${2:-}" ]; then
        THRESHOLD="$2"
        shift 2
      else
        echo "[-] ERROR: --threshold requires a numerical value." >&2
        exit 2
      fi
      ;;
    *)
      if [[ "$1" =~ ^[0-9]+$ ]]; then
        THRESHOLD="$1"
        shift
      else
        echo "[-] ERROR: Unknown argument: $1" >&2
        echo "[-] Use --help for usage instructions." >&2
        exit 2
      fi
      ;;
  esac
done

# Validate threshold range
if ! [[ "${THRESHOLD}" =~ ^[0-9]+$ ]] || [ "${THRESHOLD}" -lt 1 ] || [ "${THRESHOLD}" -gt 100 ]; then
  echo "[-] ERROR: Threshold must be an integer between 1 and 100. Provided: ${THRESHOLD}" >&2
  exit 2
fi

# Measure current disk usage on root partition
CURRENT_USAGE="$(df -P / | awk 'NR==2 {print $5}' | tr -d '%')"
TOTAL_SPACE="$(df -h / | awk 'NR==2 {print $2}')"
USED_SPACE="$(df -h / | awk 'NR==2 {print $3}')"
AVAIL_SPACE="$(df -h / | awk 'NR==2 {print $4}')"
MOUNT_POINT="/"

echo "===================================================================="
echo " HIVELET DISK STORAGE THRESHOLD MONITOR"
echo " Partition:   ${MOUNT_POINT}"
echo " Threshold:   ${THRESHOLD}%"
echo " Current:     ${CURRENT_USAGE}% (${USED_SPACE} used of ${TOTAL_SPACE}, ${AVAIL_SPACE} available)"
echo "===================================================================="

# Evaluate disk threshold condition
if [ "${CURRENT_USAGE}" -ge "${THRESHOLD}" ]; then
  echo ""
  echo "  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo "  [CRITICAL DISK ALERT] ROOT PARTITION SPACE THRESHOLD BREACHED!"
  echo "  Current Usage: ${CURRENT_USAGE}% >= Configured Threshold: ${THRESHOLD}%"
  echo "  Available:     ${AVAIL_SPACE} remaining"
  echo "  Action:        Purge temporary files or expand virtual disk space."
  echo "  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
  echo ""
  echo "[✘] Exiting with non-zero status code: 1"
  exit 1
else
  echo ""
  echo "  [✔] DISK CAPACITY OK: Usage is within safe operational limits."
  echo "  Current Usage: ${CURRENT_USAGE}% < Threshold: ${THRESHOLD}%"
  echo ""
  echo "[✔] Exiting with success status code: 0"
  exit 0
fi
