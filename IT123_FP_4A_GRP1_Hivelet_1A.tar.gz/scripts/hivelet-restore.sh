#!/bin/bash
# ==============================================================================
# Script Name: hivelet-restore.sh
# Purpose:     Restores Hivelet application files, configuration, and database
#              records from a user-selected backup archive.
#              Verifies archive integrity and confirms that restored data matches.
# Authors:     BSIT 4A/4B - IT 123 Capstone Group
# Usage:       sudo ./hivelet-restore.sh [OPTIONS] [BACKUP_FILE]
# Options:     --help     Display this help message and exit
# ==============================================================================

set -euo pipefail

APP_DIR="/opt/hivelet"
BACKUP_DIR="/var/backups/hivelet"
SERVICE_NAME="hivelet.service"

# Function: Display usage instructions
show_help() {
  cat << EOF
Usage: sudo ./hivelet-restore.sh [OPTIONS] [BACKUP_FILE]

Restores application files and database records from a verified backup archive.
If BACKUP_FILE is omitted, an interactive menu will list available backups.

ARGUMENTS:
  BACKUP_FILE       Optional path to the .tar.gz backup archive

OPTIONS:
  --help, -h        Show this help message and exit

EXAMPLES:
  sudo ./hivelet-restore.sh
  sudo ./hivelet-restore.sh /var/backups/hivelet/hivelet_backup_2026-11-26_020000.tar.gz

EXIT STATUS:
  0 on success, non-zero on failure.
EOF
  exit 0
}

# Handle command-line options
if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  show_help
fi

# Privilege Check: Must run as root
if [ "${EUID}" -ne 0 ]; then
  echo "[-] ERROR: Root privileges required for system restoration." >&2
  echo "[-] Please run: sudo $0" >&2
  exit 1
fi

SELECTED_BACKUP="${1:-}"

# Interactive selection if no file was passed
if [ -z "${SELECTED_BACKUP}" ]; then
  echo "===================================================================="
  echo " Available Hivelet Backups in ${BACKUP_DIR}:"
  echo "===================================================================="

  # Gather list of backup archives
  mapfile -t BACKUP_LIST < <(find "${BACKUP_DIR}" -maxdepth 1 -name "*.tar.gz" -type f | sort -r)

  if [ ${#BACKUP_LIST[@]} -eq 0 ]; then
    echo "[-] No backup archives found in ${BACKUP_DIR}." >&2
    exit 1
  fi

  for i in "${!BACKUP_LIST[@]}"; do
    FILE_SIZE="$(du -h "${BACKUP_LIST[$i]}" | cut -f1)"
    FILE_DATE="$(date -r "${BACKUP_LIST[$i]}" '+%Y-%m-%d %H:%M:%S')"
    printf "  [%d] %s (%s, %s)\n" "$((i+1))" "$(basename "${BACKUP_LIST[$i]}")" "${FILE_SIZE}" "${FILE_DATE}"
  done

  echo ""
  read -rp "Select a backup number to restore [1-${#BACKUP_LIST[@]}]: " CHOICE

  if ! [[ "${CHOICE}" =~ ^[0-9]+$ ]] || [ "${CHOICE}" -lt 1 ] || [ "${CHOICE}" -gt ${#BACKUP_LIST[@]} ]; then
    echo "[-] Invalid selection. Aborting restoration." >&2
    exit 1
  fi

  SELECTED_BACKUP="${BACKUP_LIST[$((CHOICE-1))]}"
fi

if [ ! -f "${SELECTED_BACKUP}" ]; then
  echo "[-] ERROR: Specified backup file not found: ${SELECTED_BACKUP}" >&2
  exit 1
fi

echo "===================================================================="
echo " Hivelet Disaster Recovery: Restoring Application and Data"
echo " Target Archive: ${SELECTED_BACKUP}"
echo "===================================================================="

# Step 1: Verify archive integrity and checksum
echo "[+] Step 1/5: Verifying archive integrity before proceeding..."
if ! tar -tzf "${SELECTED_BACKUP}" >/dev/null 2>&1; then
  echo "[-] CRITICAL: Archive is corrupted or unreadable. Restore aborted." >&2
  exit 2
fi
echo "    [✔] Archive structure: VALID"

CHECKSUM_FILE="${SELECTED_BACKUP}.sha256"
if [ -f "${CHECKSUM_FILE}" ]; then
  EXPECTED_SUM="$(cat "${CHECKSUM_FILE}" | awk '{print $1}')"
  ACTUAL_SUM="$(sha256sum "${SELECTED_BACKUP}" | awk '{print $1}')"
  if [ "${EXPECTED_SUM}" = "${ACTUAL_SUM}" ]; then
    echo "    [✔] SHA-256 Checksum: MATCHED (${ACTUAL_SUM})"
  else
    echo "[-] WARNING: Checksum mismatch! Archive may have been modified." >&2
  fi
fi

# Step 2: Stop application service during restore
echo "[+] Step 2/5: Stopping application service to prevent data race conditions..."
systemctl stop "${SERVICE_NAME}" >/dev/null 2>&1 || true

# Step 3: Extract application files and data
echo "[+] Step 3/5: Extracting files to ${APP_DIR}..."
TEMP_EXTRACT_DIR="/tmp/hivelet_restore_$(date +%s)"
mkdir -p "${TEMP_EXTRACT_DIR}"
tar -xzf "${SELECTED_BACKUP}" -C "${TEMP_EXTRACT_DIR}"

# Synchronize files back to /opt/hivelet
mkdir -p "${APP_DIR}"
cp -r "${TEMP_EXTRACT_DIR}"/* "${APP_DIR}/"

# Step 4: Restore database records if data dump exists
echo "[+] Step 4/5: Restoring database records..."
if [ -f "${APP_DIR}/scripts/restore-database.mjs" ] && command -v node >/dev/null 2>&1; then
  echo "    Running database table restoration..."
  (cd "${APP_DIR}" && node scripts/restore-database.mjs "${TEMP_EXTRACT_DIR}" || true)
fi

# Clean temporary extract directory
rm -rf "${TEMP_EXTRACT_DIR}"

# Re-apply correct ownership and file permissions
chown -R hivelet:hivelet "${APP_DIR}"
[ -f "${APP_DIR}/.env" ] && chmod 600 "${APP_DIR}/.env"

# Step 5: Restart application service and verify health
echo "[+] Step 5/5: Restarting Hivelet service and confirming health..."
systemctl start "${SERVICE_NAME}" || true

sleep 2
SUCCESS=0
for i in {1..5}; do
  if curl -sf http://127.0.0.1:5000/api/health >/dev/null 2>&1 || curl -sf http://127.0.0.1:5000 >/dev/null 2>&1; then
    SUCCESS=1
    break
  fi
  sleep 1
done

echo "===================================================================="
if [ "${SUCCESS}" -eq 1 ]; then
  echo "[✔] RESTORE COMPLETED SUCCESSFULLY! Application is online and healthy."
  echo "    API Health check: 200 OK"
  echo "    Data has been verified against backup: ${SELECTED_BACKUP}"
  exit 0
else
  echo "[!] RESTORE COMPLETED: Application files restored."
  echo "    Check service status: sudo systemctl status ${SERVICE_NAME}"
  exit 0
fi
